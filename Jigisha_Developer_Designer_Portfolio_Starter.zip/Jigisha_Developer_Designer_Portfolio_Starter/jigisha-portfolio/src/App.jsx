import React from 'react'
import { ArrowUpRight, Github, Linkedin, Mail, Menu, Sparkles, Code2, PenTool, Layers3, ExternalLink } from 'lucide-react'

const projects = [
  {
    number: '01',
    name: 'GlaucoVision',
    type: 'AI · Healthcare technology',
    description: 'A team initiative exploring AI-assisted glaucoma screening and monitoring through retinal image analysis.',
    role: 'Co-founder · Product and outreach contribution',
    tags: ['AI / ML', 'Healthcare', 'Product'],
    note: 'Project scope and individual technical contribution to be detailed in the case study.'
  },
  {
    number: '02',
    name: 'DataShield AI',
    type: 'Cybersecurity · Web application',
    description: 'A team project focused on an AI-assisted web vulnerability assessment experience.',
    role: 'Team project · Individual contribution to confirm',
    tags: ['Web security', 'AI', 'Dashboard'],
    note: 'Add verified repository, live demo and the exact features personally implemented.'
  },
  {
    number: '03',
    name: 'EnterpriseIQ',
    type: 'Document intelligence · RAG',
    description: 'A document-intelligence assistant concept and development effort involving retrieval-augmented generation.',
    role: 'Collaborative project · Confirm current build status',
    tags: ['React', 'RAG', 'Document workflows'],
    note: 'Publish as a completed product only after confirming the working build and personal contribution.'
  },
  {
    number: '04',
    name: 'BrailleGo',
    type: 'Assistive technology · Hardware',
    description: 'An assistive Braille keyboard project recognised as First Runner-Up at IAC 2K23, NIT Jamshedpur.',
    role: 'Team project · Award-winning initiative',
    tags: ['Accessibility', 'Assistive tech', 'Innovation'],
    note: 'Add the project story, prototype photographs and your specific responsibilities.'
  },
  {
    number: '05',
    name: 'DMK WebForge',
    type: 'Web experiences · Client coordination',
    description: 'A web-services initiative involving client communication, requirement gathering and project coordination.',
    role: 'Co-founder · Operations and client coordination',
    tags: ['Web', 'Client communication', 'Delivery'],
    note: 'Add only client websites you have permission to show, with your exact design or development contribution.'
  }
]

function SectionHeading({ eyebrow, title, text }) {
  return <div className="mb-10 max-w-2xl">
    <p className="eyebrow">{eyebrow}</p>
    <h2 className="section-title">{title}</h2>
    {text && <p className="mt-3 leading-7 text-muted">{text}</p>}
  </div>
}

function App() {
  return <div className="min-h-screen bg-paper text-ink">
    <header className="sticky top-0 z-20 border-b border-line/80 bg-paper/90 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 md:px-8">
        <a href="#home" className="text-sm font-semibold tracking-tight sm:text-base">Jigisha Diksha<span className="text-accent">.</span></a>
        <div className="hidden items-center gap-8 text-sm text-muted md:flex">
          <a className="navlink" href="#about">About</a><a className="navlink" href="#work">Selected work</a>
          <a className="navlink" href="#capabilities">Capabilities</a><a className="navlink" href="#contact">Contact</a>
        </div>
        <a href="#contact" className="inline-flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-sm text-white transition hover:bg-accent">Let's talk <ArrowUpRight size={15}/></a>
      </nav>
    </header>

    <main>
      <section id="home" className="mx-auto grid max-w-6xl gap-12 px-5 pb-24 pt-20 md:grid-cols-[1.2fr_.8fr] md:items-center md:px-8 md:pb-32 md:pt-28">
        <div>
          <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 text-xs text-muted"><span className="h-2 w-2 rounded-full bg-accent"/> Open to meaningful opportunities</div>
          <p className="eyebrow">Developer · Product Designer · Creative Technologist</p>
          <h1 className="mt-4 max-w-3xl text-5xl font-semibold leading-[1.04] tracking-[-0.055em] sm:text-6xl lg:text-7xl">I build useful digital experiences.</h1>
          <p className="mt-7 max-w-xl text-lg leading-8 text-muted">I bring technology, product thinking and visual design together to turn ideas into clear, thoughtful experiences.</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <a href="#work" className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3 text-sm font-medium text-white hover:bg-ink">Explore my work <ArrowUpRight size={16}/></a>
            <a href="#contact" className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-5 py-3 text-sm font-medium hover:border-ink">Get in touch</a>
          </div>
          <div className="mt-12 flex flex-wrap gap-x-7 gap-y-3 text-sm text-muted">
            <span className="inline-flex items-center gap-2"><Code2 size={15}/> Development</span>
            <span className="inline-flex items-center gap-2"><Layers3 size={15}/> Product design</span>
            <span className="inline-flex items-center gap-2"><PenTool size={15}/> Visual design</span>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/5] overflow-hidden rounded-[2rem] border border-line bg-[#e9eee9] p-7 md:p-9">
            <div className="flex h-full flex-col justify-between rounded-[1.4rem] border border-[#d6dfd7] bg-[#f4f6f2] p-6">
              <div className="flex items-center justify-between text-xs uppercase tracking-[.18em] text-muted"><span>Selected disciplines</span><Sparkles size={16}/></div>
              <div>
                <div className="mb-3 h-px w-full bg-[#d8e0d8]"/>
                <p className="text-4xl font-medium leading-tight tracking-[-.05em]">Think<br/>clearly.<br/><span className="text-accent">Build</span><br/>carefully.</p>
                <p className="mt-5 max-w-[14rem] text-sm leading-6 text-muted">A considered mix of engineering, research and craft.</p>
              </div>
              <div className="flex items-end justify-between"><span className="text-xs text-muted">PORTFOLIO / 2026</span><span className="text-3xl text-accent">✳</span></div>
            </div>
          </div>
          <div className="absolute -bottom-5 -left-5 rounded-2xl border border-line bg-white px-5 py-4 shadow-sm"><p className="text-xs text-muted">Based in</p><p className="mt-1 font-medium">Ranchi, India</p></div>
        </div>
      </section>

      <section id="about" className="border-y border-line bg-white">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-[.7fr_1.3fr] md:px-8 md:py-24">
          <div><p className="eyebrow">01 / About</p><h2 className="section-title mt-3">A little about me.</h2></div>
          <div className="max-w-3xl">
            <p className="text-xl leading-9 tracking-tight text-ink">I’m Jigisha Diksha, a Computer Science graduate interested in building digital products that are useful, accessible and thoughtfully designed.</p>
            <p className="mt-5 leading-8 text-muted">My interests sit at the intersection of software development, product design, research and creative communication. I enjoy understanding a problem, shaping the experience and collaborating to move an idea toward a working solution.</p>
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              <div className="rounded-2xl bg-paper p-5"><p className="font-medium">How I think</p><p className="mt-2 text-sm leading-6 text-muted">Start with the user and the problem; make the solution understandable before making it complex.</p></div>
              <div className="rounded-2xl bg-paper p-5"><p className="font-medium">How I work</p><p className="mt-2 text-sm leading-6 text-muted">Research, collaborate, prototype, test and improve with clear communication.</p></div>
            </div>
          </div>
        </div>
      </section>

      <section id="work" className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-24">
        <SectionHeading eyebrow="02 / Selected work" title="Projects with a purpose." text="A selection of collaborative projects and initiatives across technology, product thinking and digital experiences. Case studies will be expanded with verified contributions, visuals and working links."/>
        <div className="grid gap-5 md:grid-cols-2">
          {projects.map((p, i) => <article key={p.number} className={`project-card ${i === 0 ? 'md:col-span-2 md:grid md:grid-cols-[.85fr_1.15fr]' : ''}`}>
            <div className="project-art">
              <span className="text-xs tracking-[.2em] text-[#748078]">{p.number} / FEATURED PROJECT</span>
              <div className="my-10 flex flex-1 items-center justify-center"><div className="project-mark">{p.name.split(/[\s]/).map(x=>x[0]).join('').slice(0,3)}</div></div>
              <span className="text-xs uppercase tracking-[.15em] text-[#748078]">{p.type}</span>
            </div>
            <div className="flex flex-col justify-center p-7 md:p-9">
              <p className="eyebrow">{p.type}</p><h3 className="mt-3 text-2xl font-semibold tracking-tight">{p.name}</h3>
              <p className="mt-4 leading-7 text-muted">{p.description}</p>
              <p className="mt-5 text-sm"><span className="font-medium">Role:</span> <span className="text-muted">{p.role}</span></p>
              <div className="mt-5 flex flex-wrap gap-2">{p.tags.map(t=><span key={t} className="rounded-full border border-line px-3 py-1 text-xs text-muted">{t}</span>)}</div>
              <p className="mt-5 border-t border-line pt-4 text-xs leading-5 text-muted">{p.note}</p>
            </div>
          </article>)}
        </div>
      </section>

      <section id="capabilities" className="border-y border-line bg-white">
        <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-24">
          <SectionHeading eyebrow="03 / Capabilities" title="Where I add value." text="A growing toolkit across engineering, product design and visual communication. Specific tools and proficiency levels should be listed only where they reflect hands-on experience."/>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              {icon:<Code2/>, title:'Development', body:'Frontend and full-stack application development, responsive interfaces, APIs and integration.'},
              {icon:<Layers3/>, title:'Product & UX', body:'User research, problem framing, information architecture, wireframes and interactive prototypes.'},
              {icon:<PenTool/>, title:'Creative technology', body:'Visual storytelling, brand systems, graphic communication and design-led digital experiences.'}
            ].map(x=><div key={x.title} className="rounded-2xl border border-line p-7"><div className="mb-8 inline-flex rounded-xl bg-paper p-3 text-accent">{x.icon}</div><h3 className="text-lg font-semibold">{x.title}</h3><p className="mt-3 text-sm leading-7 text-muted">{x.body}</p></div>)}
          </div>
        </div>
      </section>

      <section id="contact" className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="rounded-[2rem] bg-ink px-7 py-12 text-white md:px-14 md:py-16">
          <p className="text-xs uppercase tracking-[.2em] text-white/50">04 / Contact</p>
          <h2 className="mt-5 max-w-2xl text-4xl font-semibold tracking-[-.04em] md:text-5xl">Have a thoughtful project in mind?</h2>
          <p className="mt-5 max-w-xl leading-7 text-white/65">I’m interested in opportunities to build, design and collaborate. Reach out and let’s start a conversation.</p>
          <a href="mailto:jigishadiksha8757@gmail.com" className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-medium text-ink hover:bg-[#dfe9e1]">Email me <ArrowUpRight size={16}/></a>
          <div className="mt-12 flex flex-wrap gap-5 border-t border-white/15 pt-6 text-sm text-white/70">
            <a className="inline-flex items-center gap-2 hover:text-white" href="https://www.linkedin.com/in/jigisha-diksha-240a53372/" target="_blank" rel="noreferrer"><Linkedin size={16}/> LinkedIn</a>
            <a className="inline-flex items-center gap-2 hover:text-white" href="https://github.com/Jigisha-Diksha" target="_blank" rel="noreferrer"><Github size={16}/> GitHub</a>
            <a className="inline-flex items-center gap-2 hover:text-white" href="mailto:jigishadiksha8757@gmail.com"><Mail size={16}/> Email</a>
          </div>
        </div>
      </section>
    </main>
    <footer className="border-t border-line px-5 py-6 text-center text-xs text-muted">© {new Date().getFullYear()} Jigisha Diksha. Designed with clarity and intent.</footer>
  </div>
}
export default App
