# Jigisha Diksha — Portfolio starter

A clean, minimal React + Tailwind CSS portfolio scaffold.

## Run locally
1. Install Node.js (LTS).
2. In this folder, run `npm install`.
3. Run `npm run dev`.
4. Open the local URL printed by Vite.

## Build
Run `npm run build`. The production site is generated in `dist/`.

## Deploy to Vercel
1. Push this project to a GitHub repository.
2. Sign in to Vercel and import that repository.
3. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
4. Deploy. Vercel will assign a free `*.vercel.app` URL.

## Before publishing — important accuracy checklist
- Verify Jigisha's exact personal contribution to each project.
- EnterpriseIQ is marked as a collaborative effort and its current build status must be confirmed before presenting it as a completed product.
- Add only live demo and repository links that work and that you are authorised to share.
- Add screenshots, prototypes and design work you personally created.
- Add client websites to DMK WebForge only with permission; state whether your role was design, development, coordination or a combination.
- Add a downloadable CV only after selecting the correct developer-focused CV.
- Confirm email, LinkedIn and GitHub links.

## Structure
- `src/App.jsx` — page content and project data
- `src/styles.css` — visual styling
- `tailwind.config.js` — Tailwind configuration
- `index.html` — page metadata
