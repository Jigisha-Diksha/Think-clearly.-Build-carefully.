/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: {
    fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'] },
    colors: { ink: '#17211d', muted: '#69736d', paper: '#f7f8f6', line: '#e4e8e3', accent: '#315c4b' }
  }},
  plugins: []
}